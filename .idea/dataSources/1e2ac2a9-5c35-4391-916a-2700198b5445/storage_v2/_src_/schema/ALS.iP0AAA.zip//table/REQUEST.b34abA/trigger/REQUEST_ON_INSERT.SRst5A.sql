create trigger REQUEST_ON_INSERT
    before insert
    on REQUEST
    for each row
BEGIN
SELECT REQUEST_SEQUENCE.NEXTVAL
INTO :NEW.ID
FROM DUAL;
END;
/

